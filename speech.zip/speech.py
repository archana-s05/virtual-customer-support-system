import speech_recognition as sr
import pyttsx3
from whoosh.index import create_in
from whoosh.fields import Schema, TEXT
from whoosh.qparser import QueryParser
import os

# Set up text-to-speech engine
engine = pyttsx3.init()

# Initialize recognizer for speech recognition
recognizer = sr.Recognizer()

# Define a schema for the search engine
schema = Schema(title=TEXT(stored=True), content=TEXT(stored=True))

# Create a directory for index if it doesn't exist
if not os.path.exists("index"):
    os.mkdir("index")

# Create an index for search
ix = create_in("index", schema)

# Sample data to be indexed
documents = [
    {"title": "Python Basics", "content": "Python is a versatile programming language."},
    {"title": "Machine Learning", "content": "Machine learning is a subfield of artificial intelligence."},
    {"title": "Web Development", "content": "Web development involves creating websites and applications."},
]

# Index the sample documents
writer = ix.writer()
for doc in documents:
    writer.add_document(title=doc["title"], content=doc["content"])
writer.commit()

# Function to speak a text
def speak(text):
    engine.say(text)
    engine.runAndWait()

# Function to listen to the user's speech
def listen():
    with sr.Microphone() as source:
        print("Listening for your search query...")
        audio = recognizer.listen(source)
        print("Recognizing speech...")
        try:
            query = recognizer.recognize_google(audio)
            print(f"You said: {query}")
            return query
        except sr.UnknownValueError:
            print("Sorry, I couldn't understand that.")
            return None
        except sr.RequestError as e:
            print(f"Error with the speech recognition service: {e}")
            return None

# Function to search the query in the indexed documents
def search(query):
    with ix.searcher() as searcher:
        query_parser = QueryParser("content", ix.schema)
        query_obj = query_parser.parse(query)
        results = searcher.search(query_obj)
        if results:
            for result in results:
                print(f"Found: {result['title']} - {result['content']}")
                speak(f"Found: {result['title']}")
        else:
            print("No results found.")
            speak("No results found.")

# Main program loop
def main():
    speak("Hello, I am your voice-based search engine. What do you want to search for?")
    while True:
        query = listen()
        if query:
            search(query)
        else:
            speak("Please try again.")

if __name__ == "__main__":
    main()
