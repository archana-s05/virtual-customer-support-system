import nltk
import random

# Download necessary NLTK resources
nltk.download('punkt')
nltk.download('stopwords')

# Predefined responses for the virtual support system
responses = {
    "greeting": ["Hello! How can I assist you today?", "Hi! How can I help you?", "Good day! What can I do for you?"],
    "farewell": ["Goodbye! Have a great day!", "Thanks for contacting us. Bye!", "Goodbye, take care!"],
    "help": ["I'm here to assist you with any issues. Could you tell me what you're facing?", 
             "I can help you with various services. What can I do for you?", 
             "Tell me more about the problem, and I’ll do my best to help!"],
    "unknown": ["Sorry, I didn't quite understand that. Could you please clarify?", 
                "I'm not sure about that. Could you rephrase?", 
                "Could you please explain again?"]
}

# Function to detect user intent
def get_response(user_input):
    # Tokenizing the input and converting to lowercase
    user_input = user_input.lower()
    tokens = nltk.word_tokenize(user_input)
    
    # Check if the user is greeting
    greetings = ['hello', 'hi', 'hey', 'greetings', 'morning', 'good']
    farewells = ['bye', 'goodbye', 'see you', 'later']
    
    if any(greeting in tokens for greeting in greetings):
        return random.choice(responses["greeting"])
    elif any(farewell in tokens for farewell in farewells):
        return random.choice(responses["farewell"])
    elif "help" in tokens:
        return random.choice(responses["help"])
    else:
        return random.choice(responses["unknown"])

# Main function to interact with the user
def customer_support():
    print("Virtual Customer Support: Hello! How can I assist you today?")
    
    while True:
        user_input = input("You: ")
        
        # Check for exit condition
        if user_input.lower() in ['exit', 'quit', 'bye', 'goodbye']:
            print("Virtual Customer Support: Goodbye! Have a great day!")
            break
        
        # Get the system's response based on the user's input
        response = get_response(user_input)
        print(f"Virtual Customer Support: {response}")

# Run the customer support system
if __name__ == "__main__":
    customer_support()
