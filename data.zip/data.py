import speech_recognition as sr

# Initialize recognizer
recognizer = sr.Recognizer()

# Use the microphone
with sr.Microphone() as source:
    print("Say something...")
    audio = recognizer.listen(source)

    try:
        text = recognizer.recognize_google(audio)
        print(f"You said: {text}")
    except sr.UnknownValueError:
        print("Sorry, I could not understand your speech.")
    except sr.RequestError:
        print("Could not request results from Google Speech Recognition.")
